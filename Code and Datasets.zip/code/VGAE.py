
import torch
from torch_geometric.nn import GCNConv
import networkx as nx
import matplotlib.pyplot as plt


class VGAE(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, hidden_dim2):
        super(VGAE, self).__init__()
        torch.manual_seed(1234)
        self.in_dim = in_dim
        self.hidden_dim = hidden_dim
        self.hidden_dim2 = hidden_dim2

        self.conv1 = GCNConv(in_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim2)
        self.conv3 = GCNConv(hidden_dim, hidden_dim2)
        self.conv4 = GCNConv(hidden_dim, hidden_dim2)
        self.conv5 = GCNConv(hidden_dim, hidden_dim2)


    def encoder(self, X, A):
        h = self.conv1(X, A)
        h = h.relu()
        self.mean = self.conv2(h, A)
        self.log_std = self.conv3(h, A)
        self.mean1 = self.conv4(h, A)
        self.log_std1 = self.conv5(h, A)
        Gaussian_noise = torch.randn(X.size(0), self.hidden_dim2)
        Gaussian_noise1 = torch.randn(X.size(0), self.hidden_dim2)
        sampled_z = 0.5*(self.mean + Gaussian_noise * torch.exp(self.log_std))+\
                    0.5*(self.mean + 0.001*Gaussian_noise1 * torch.exp(self.log_std1))

        return sampled_z


    def decoder(self, z):
        adj = torch.sigmoid(torch.matmul(z, z.t()))
        return adj


    def forward(self, X, G):
        z = self.encoder(X, G)
        adj = self.decoder(z)
        return adj, z

def compute_loss_para(data):
    pos_weight = (data.x.shape[0] * data.x.shape[0] - data.edge_index.shape[1]) / data.edge_index.shape[1]
    norm = data.x.shape[0] * data.x.shape[0] / float((data.x.shape[0] * data.x.shape[0] - data.edge_index.shape[1]) * 2)
    adj = torch.sparse_coo_tensor(torch.LongTensor(data.edge_index),
                                   torch.FloatTensor(torch.ones(data.edge_index.shape[1])),
                                   torch.Size((data.x.shape[0], data.x.shape[0])))
    weight_mask = adj.to_dense().view(-1) == 1
    weight_tensor = torch.ones(weight_mask.size(0))
    weight_tensor[weight_mask] = pos_weight
    return weight_tensor, norm

def compute_loss_para_2(data):
    pos_weight = (data.x.shape[0] * data.x.shape[0] - data.edge_index.shape[1]) / data.edge_index.shape[1]
    norm = data.x.shape[0] * data.x.shape[0] / float((data.x.shape[0] * data.x.shape[0] - data.edge_index.shape[1]) * 2)

    return  norm


def visualize_graph(G, color,filename):
    plt.figure(figsize=(20,20))
    plt.xticks([])
    plt.yticks([])
    plt.title(filename[:-5])
    nx.draw_networkx (G, pos=nx.spring_layout(G, seed=42), with_labels=False, node_color=color, cmap="Set2")
    plt.show()


def visualize_embedding(h, color, epoch=None, loss=None):
    plt.figure(figsize=(7, 7))
    plt.xticks([])
    plt.yticks([])
    h = h.detach().cpu().numpy()
    plt.scatter(h[:, 0], h[:, 1], s=140, c=color, cmap="Set2")
    if epoch is not None and loss is not None:
        print(plt.xlabel("Epoch:{}, Loss:{}".format(epoch, loss)))
    plt.show()