import numpy as np
import os
import arff
import torch
import pandas as pd
from torch_geometric.data import Data
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from construct_ICG import getG

def make_arff(X, y, name, path):
    col_names = []
    col_types = []
    for i in range(X.shape[1]):
        col_names.append('attr{}'.format(i+1))
        col_types.append('NUMERIC')
    df = pd.DataFrame(X, columns=col_names)
    df['class'] = y.astype(int).astype(str)
    col_names.append('class')
    col_types.append(list(np.unique(y).astype(int).astype(str)))

    arff_data = {
        'description': name,
        'relation': name[:-5],
        'attributes': [(col_names[i], col_types[i]) for i in range(len(col_names))],
        'data': df.values.tolist()
    }
    with open(os.path.join(path, name), 'w') as f:
        arff.dump(arff_data, f)

def preprocess(df):
    X_cols = []
    last_column = df.iloc[:, -1]
    for c in df.columns:
        if c != 'class':
            X_cols.append(c)
    X = df[X_cols]
    y = df['class']

    df = X
    df = df.dropna(axis=1, how='all')

    try:
        imputer = SimpleImputer(strategy='most_frequent')
        df[df.select_dtypes(include=['object']).columns] = imputer.fit_transform(
            df[df.select_dtypes(include=['object']).columns])
    except:
        # print("No nominal attributes")
        a=1
    try:
        imputer = SimpleImputer(strategy='mean')
        df[df.select_dtypes(include=['float']).columns] = imputer.fit_transform(
            df[df.select_dtypes(include=['float']).columns])
    except:
        # print("No numerical attributes")
        a=1

    for column in df.select_dtypes(include=['object']).columns:
        le = LabelEncoder()
        df[column] = le.fit_transform(df[column])

    scaler = StandardScaler()
    df = scaler.fit_transform(df)

    le = LabelEncoder()
    y = le.fit_transform(y)

    X = np.array(df)
    y = np.array(y)
    return X, y

def make_graph_mst(X, y):

    # X = X.astype(np.float16)

    dist=np.zeros((X.shape[0],X.shape[0]), dtype=np.float16)
    # dist = np.zeros((X.shape[0], X.shape[0]))
    for i in range(X.shape[0]):
        for j in range(i+1,X.shape[0]):
            dist[i][j]=np.sqrt(np.sum((X[i] - X[j]) ** 2))
            dist[j][i]=dist[i][j]

    edges=getG(dist)

    edge_dist = np.zeros(len(edges))
    adj = [[], []]
    for i in range(len(edges)):
        adj[0].append(edges[i][0])
        adj[1].append(edges[i][1])
        edge_dist[i]=dist[edges[i][0],edges[i][1]]

    for i in range(X.shape[0]):
        adj[0].append(i)
        adj[1].append(i)

    x = torch.tensor(X, dtype=torch.float)
    y = torch.tensor(y, dtype=torch.float)
    edge_index = torch.tensor(adj, dtype=torch.long)
    data = Data(x=x, y=y, edge_index=edge_index)

    adj = torch.sparse_coo_tensor(torch.LongTensor(data.edge_index),
                                   torch.FloatTensor(torch.ones(data.edge_index.shape[1])),
                                   torch.Size((data.x.shape[0], data.x.shape[0])))

    return data, adj

