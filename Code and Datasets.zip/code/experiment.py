import os
import numpy as np
import pandas as pd
from scipy.io import arff
import ICGNB as ICGNB
from utils import preprocess, make_graph_mst
from datetime import datetime
import re


def preprocess_arff(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    processed_lines = []
    for line in lines:
        if line.strip().lower().startswith('@attribute'):
            line = re.sub(r'\{([^}]*)\}', lambda m: '{' + m.group(1).replace(' ', '') + '}', line)
        processed_lines.append(line)

    temp_file_path = 'temp_preprocessed.arff'
    with open(temp_file_path, 'w') as file:
        file.writelines(processed_lines)

    processed_lines = []
    data_section = False
    for line in lines:
        if line.strip().lower().startswith('@attribute'):
            line = re.sub(r'\{([^}]*)\}', lambda m: '{' + m.group(1).replace(' ', '') + '}', line)
            processed_lines.append(line)
            continue
        if data_section:
            line = re.sub(r'\s*,\s*', ',', line.strip() + '\n')
        elif line.strip().lower() == '@data':
            data_section = True
        processed_lines.append(line)

    temp_file_path = 'temp_preprocessed.arff'
    with open(temp_file_path, 'w') as file:
        file.writelines(processed_lines)

    return temp_file_path


def read_arff(file_path):
    data, meta = arff.loadarff(file_path)
    df = pd.DataFrame(data)
    df.rename(columns={df.columns[df.columns.get_loc(df.columns[-1])]: 'class'}, inplace=True)
    now = datetime.now()
    formatted_now = now.strftime("%Y-%m-%d %H:%M:%S")
    print(formatted_now + ' ' + file_path)

    X, y = preprocess(df)
    return X, y


def experiment(dir_name):
    entries = os.listdir(dir_name)
    file_count = sum(os.path.isfile(os.path.join(dir_name, entry)) for entry in entries)

    total_path = dir_name
    run_num = 1
    algorithm_num = 2
    np.random.seed(42)
    random_seeds = np.random.randint(1, 10001, size=run_num)

    result = []
    result_number = []
    dataset_name = []
    for filename in os.listdir(total_path):

        dataset_name.append(filename[:-5])
        file_path = os.path.join(total_path, filename)
        X, y = read_arff(file_path)

        result_file = np.zeros(algorithm_num)
        result_file_10 = np.zeros((run_num, algorithm_num))

        data, adj = make_graph_mst(X, y)

        for i in range(run_num):
            now = datetime.now()
            formatted_now = now.strftime("%Y-%m-%d %H:%M:%S")
            print("============= The " + str(i + 1) + "-th iteration " + formatted_now + " =============")

            result_i = ICGNB.run(X, y, data, adj, data, adj, random_seeds[i])
            result_i = result_i * 100
            result_file_10[i] = result_i
            result_file += result_i

        means = np.mean(result_file_10, axis=0)
        vars = np.std(result_file_10, axis=0)
        result_file_10 = np.vstack((result_file_10, means, vars))
        result_file_10 = np.around(result_file_10, 2)
        df = pd.DataFrame(result_file_10)

        result_file_10_str = result_file_10.astype(str)
        result_file_mean_std = []
        for i in range(algorithm_num):
            m = result_file_10_str[-2][i]
            s = result_file_10_str[-1][i]
            if m[-3] != '.':
                m += '0'
            if s[-3] != '.':
                s += '0'
            m_s = m + '±' + s
            result_file_mean_std.append(m_s)
        result.append(result_file_mean_std)
        result_number.append(result_file_10[-2])

        print(
            "{:<20}\t{:<12}\t{}"
            .format('Dataset', 'GNB', 'ICGNB'))
        print("{:<20}\t".format(dataset_name[-1]), end='')
        for j in range(algorithm_num):
            print("{:<12}\t".format(result[len(result) - 1][j]), end='')
        print('')

    dataset_name.append('Average')
    result.append(np.around(np.mean(result_number, axis=0), 2))
    print(
        "{:<20}\t{:<12}\t{}"
        .format('Dataset', 'GNB', 'ICGNB'))
    for i in range(file_count + 1):
        print("{:<20}\t".format(dataset_name[i]), end='')
        for j in range(algorithm_num):
            print("{:<12}\t".format(result[i][j]), end='')
        print('')


if __name__ == "__main__":
    # Please modify "dir_path" to the path where your datasets are stored
    dir_path = r'..\dataset'
    experiment(dir_path)
