from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
from LBFGS import L_BFGS_B
from WeightedGaussNB import WeightedGaussNB
from VGAE import *
import numpy as np
from tqdm import trange


def run(X, y, data1, adj1, data2, adj2, random_seed):

    n_inst=data1.x.shape[1]
    model1 = VGAE(n_inst, 2*n_inst, n_inst)
    model2 = VGAE(n_inst, 2*n_inst, n_inst)

    optimizer1 = torch.optim.Adam(model1.parameters(), lr=0.01)
    weight_tensor1, norm1 = compute_loss_para(data1)
    optimizer2 = torch.optim.Adam(model2.parameters(), lr=0.01)
    weight_tensor2, norm2 = compute_loss_para(data2)

    clf = GaussianNB()

    print('VGAE',end=' ')
    num_epoch=501
    for epoch in trange(num_epoch):

        logits1, z1 = model1.forward(data1.x, data1.edge_index)
        loss1 = norm1 * F.binary_cross_entropy(logits1.view(-1), adj1.to_dense().view(-1), weight=weight_tensor1)
        kl_divergence1 = 0.5 / logits1.size(0) * (
                1 + 2 * model1.log_std - model1.mean ** 2 - torch.exp(model1.log_std) ** 2).sum(1).mean()
        loss1 -= kl_divergence1
        optimizer1.zero_grad()
        loss1.backward()
        optimizer1.step()

        logits2, z2 = model2.forward(data2.x, data2.edge_index)
        loss2 = norm2 * F.binary_cross_entropy(logits2.view(-1), adj2.to_dense().view(-1), weight=weight_tensor2)
        kl_divergence2 = 0.5 / logits2.size(0) * (
                1 + 2 * model2.log_std - model2.mean ** 2 - torch.exp(model2.log_std) ** 2).sum(1).mean()
        loss2 -= kl_divergence2
        optimizer2.zero_grad()
        loss2.backward()
        optimizer2.step()

        Z2 = z2.detach().numpy() #mst
        X2 = np.concatenate((X, Z2), axis=1)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=random_seed)
        X_train4, X_test4, y_train4, y_test4 = train_test_split(X2, y, test_size=0.2, random_state=random_seed)#ori+mst

        clf.fit(X_train, y_train)

        if epoch == num_epoch-1:

            clf.fit(X_train, y_train)
            s = clf.score(X_test, y_test)
            print("\nGNB:" + (str)(s))

            icgnb = WeightedGaussNB()
            icgnb.fit(X_train4, y_train4)
            w4 = L_BFGS_B(X_train4, y_train4)
            icgnb.setWeight(w4)
            ws4 = icgnb.score(X_test4, y_test4)
            print("ICGNB:" + (str)(ws4))

            result=np.array([s,ws4])

            return result